package gyak1.pm;

public class FizzBuzz {
	public static void main(final String[] args) {
		for (int i=1; i<=100; ++i) {
			if (0 == i % 3 && 0 == i % 5) {
				System.out.println("FizzBuzz");
			} else if (0 == i % 3) {
				System.out.println("Fizz");
			} else if (0 == i % 5) {
				System.out.println("Buzz");
			} else {
				System.out.println(i);
			}
		}
	}
}
