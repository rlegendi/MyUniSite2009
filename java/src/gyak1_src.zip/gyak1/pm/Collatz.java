package gyak1.pm;

public class Collatz {

	// Rekurziv fuggvenyes megoldas - ilyet meg nem vettunk, de igy is lehet.
	public static void collatz(final int n) {
		System.out.print(n + " ");

		if (1 == n) {
			System.out.println(); // sortores
			return;
		}

		if (0 == n % 2) {
			collatz(n / 2);
		} else {
			collatz(3 * n + 1);
		}
	}

	public static void main(final String[] args) {
		if (args.length != 1) {
			System.err.println("A programnak 1 param�ter kell!");
			System.exit(1);
		}

		final int N = Integer.parseInt(args[0]);
		if (N < 1 || 100 < N) {
			System.err.println("Hib�s input! N bele kelle essen az [1..100] intervallumba)!");
			System.exit(2);
		}
		
		// Rekurziv megoldas:
		// collatz(N);

		// Imperativ megoldas:
		int act = N;
		while (act != 1) {
			System.out.print(act + " ");
			act = (0 == act % 2)
					? act / 2
					: 3 * act + 1;
		}
		
		System.out.println(act);
	}
}
