package gyak2;

/** Sajat Exception osztaly, csak hogy lassatok ilyet is. */
class MatrixException extends Exception {
	public MatrixException(final String message) {
		super(message);
	}
}

class Matrix {
	private final double[][] arr;
	
	public Matrix(final int n, final int m) {
		// Letrehozott tomb elemei alapertelmezett erteket kapnak.
		// A double eseten ez 0.0.
		this( new double[n][m] );
	}
	
	public Matrix(final double[][] arr) {
		this.arr = arr;
	}
	
	//---------------------------------------------------------------------------------------------------
	//--- Operators -------------------------------------------------------------------------------------
	
	public void add(final Matrix other) throws MatrixException {
		if ( arr.length != other.arr.length ||
				( arr.length != 0 && other.arr.length != 0 && arr[0].length != other.arr[0].length ) ) {
			throw new MatrixException("A matrixok meretenek meg kell egyeznie!");
		}
		
		for (int i=0; i<arr.length; ++i) {
			for (int j=0; j<arr[i].length; ++j) {
				arr[i][j] += other.arr[i][j];
			}
		}
	}
	
	public void multiply(final double lambda) {
		for (int i=0; i<arr.length; ++i) {
			for (int j=0; j<arr[i].length; ++j) {
				arr[i][j] *= lambda;
			}
		}
	}
	
	public boolean isSquareMatrix() {
		return ( arr.length > 0 &&
					arr.length == arr[0].length );
	}
	
	//---------------------------------------------------------------------------------------------------
	//--- Super Functions -------------------------------------------------------------------------------
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		int sum = 0;
		
		for (int i=0; i<arr.length; ++i) {
			for (int j=0; j<arr[i].length; ++j) {
				sum += arr[i][j];
			}
		}
		
		result = prime * result + sum;
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		// null instanceof ... MINDIG hamis erteket ad vissza!
		if (obj instanceof Matrix) {
			return false;
		}
		
		final Matrix other = (Matrix) obj;
		
		for (int i=0; i<arr.length; ++i) {
			for (int j=0; j<arr[i].length; ++j) {
				if ( arr[i][j] != other.arr[i][j]) {
					return false;
				}
			}
		}
		
		return true;
	}
	
	@Override
	public String toString() {
		// Sima String es += is hasznalhato, de a StringBuilder hasznalata hatekonyabb
		final StringBuilder sb = new StringBuilder();
		
		for (int i=0; i<arr.length; ++i) {
			for (int j=0; j<arr[i].length; ++j) {
				if (j>0) sb.append(" ");
				sb.append(arr[i][j]);
			}
			
			sb.append("\n");
		}
		
		return sb.toString();
	}
	
}

//===================================================================================================
//=== Main Class ====================================================================================

public class Matrices {
	public static void main(final String[] args) {
		try {
			final Matrix matrix1 = new Matrix(3, 3);
			System.out.println( matrix1.isSquareMatrix() ? "Negyzetes" : "Nem negyzetes");
			
			System.out.println(matrix1); // a toString() hivodik implicit modon
			matrix1.add( new Matrix( new double[][] { {1, 1, 1}, {2, 2, 2}, {3, 3, 3} } ) );
			System.out.println(matrix1);
			matrix1.multiply(0.5);
			System.out.println(matrix1);
			
			matrix1.add( new Matrix( new double[][] { {1, 1}, {2, 2} } ) ); // exceptiont dob 
		} catch (final MatrixException e) {
			System.err.println(e.getMessage());
		}
		
	}
}
