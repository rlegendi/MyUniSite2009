package gyak2;

// TODO:
// Ezt a feladatot azert erosen at kell meg gondolni, mert ez igy gany
// :-)

// Kozos ososztaly
abstract class MyNumber { // Ha abstract --> nem lehet peldanyositani
	protected int a, b;
	
	protected MyNumber(final int a, final int b) {
		this.a = a;
		this.b = b;
	}
	
	public abstract void add(MyNumber number); // Ha abstract --> nem kell torzs 
	public abstract void substract(MyNumber number);
	public abstract void multiply(MyNumber number);
}

class Rational extends MyNumber {
	public Rational(final int a, final int b) {
		// Az ososztaly konstruktorat hivja + masik osztaly static metodusaval egyszerusit 
		super( a / Euclidean.gcd(a, b), b / Euclidean.gcd(a, b) );
		
		// Broaf, konstruktorban nem dobalunk kiveteleket
		// Azert neha kivetelt teszunk, ld. http://www.javaspecialists.eu/archive/Issue120.html
		if (0 == b) {
			throw new IllegalArgumentException("b nem lehet 0!");
		}
	}
	
	@Override
	public void add(final MyNumber number) {
		if (! (number instanceof Rational)) {
			// Ez Runtime kivetel, nem kell specifikalni, lekezelni, dobhato anelkul is
			throw new IllegalArgumentException("Racionalis parameter kell.");
		}
		
		final Rational other = (Rational) number;
		a = a * other.b + other.a * b;
		b *= other.b;
	}
	
	@Override
	public void substract(final MyNumber number) {
		if (! (number instanceof Rational)) {
			throw new IllegalArgumentException("Racionalis parameter kell.");
		}
		
		final Rational other = (Rational) number;
		a = a * other.b - other.a * b;
		b *= other.b;
	}
	
	@Override
	public void multiply(final MyNumber number) {
		if (! (number instanceof Rational)) {
			throw new IllegalArgumentException("Racionalis parameter kell.");
		}
		
		final Rational other = (Rational) number;
		a *= other.a;
		b *= other.b;
	}
	
	@Override
	public String toString() {
		if ( 1 == b ) {
			return "" + a;
		}
		
		if ( a == b ) {
			return "1";
		}
		
		return a + " / " + b;
	}
}

class Complex extends MyNumber {
	public Complex(final int a, final int b) {
		super(a, b);
	}
	
	@Override
	public void add(final MyNumber number) {
		if (! (number instanceof Complex)) {
			// Ez Runtime kivetel, nem kell specifikalni, lekezelni, dobhato anelkul is
			throw new IllegalArgumentException("Komplex parameter kell.");
		}
		
		final Complex other = (Complex) number;
		a += other.a;
		b += other.b;
	}
	
	@Override
	public void substract(final MyNumber number) {
		if (! (number instanceof Complex)) {
			throw new IllegalArgumentException("Racionalis parameter kell.");
		}
		
		final Complex other = (Complex) number;
		a -= other.a;
		b -= other.b;
	}
	
	@Override
	public void multiply(final MyNumber number) {
		if (! (number instanceof Complex)) {
			throw new IllegalArgumentException("Racionalis parameter kell.");
		}
		
		final Complex other = (Complex) number;
		a *= other.a;
		b *= other.b;
	}
	
	@Override
	public String toString() {
		return a + " + " + b +"i";
	}
	
	public double length() {
		return Math.sqrt( a * a + b * b );
	}
}

public class Numbers {
	private static void testRational() {
		final Rational r = new Rational(3, 4);
		r.add(new Rational(1,4));
		System.out.println(r);
		
		final Rational x = new Rational(1, 2);
		final Rational y = new Rational(1, 3);
		
		System.out.println(x);
		
		x.add(y);
		System.out.println("Hozzaadva: " + x);
		
		x.substract(y);
		System.out.println("Kivonva: " + x);
		
		x.multiply(y);
		System.out.println("Szorozva: " + x);
	}
	
	private static void testComplex() {
		final Complex a = new Complex(1, 2);
		final Complex b = new Complex(2, 3);
		
		System.out.println(a);
		
		a.add(b);
		System.out.println("Hozzaadva: " + b);
		
		a.substract(b);
		System.out.println("Kivonva: " + b);
		
		a.multiply(b);
		System.out.println("Szorozva: " + b);
		
		System.out.println("Hossza: " + a.length());
	}
	
	public static void main(final String[] args) {
		testRational();
		testComplex();
	}
}
